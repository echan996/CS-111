#!/usr/local/cs/execline-2.1.4.5/bin/execlineb

redirfd -w 1 c
redirfd -a 2 d
pipeline {
    sort medium
} pipeline {
    cat b -
}
tr a-z A-Z
